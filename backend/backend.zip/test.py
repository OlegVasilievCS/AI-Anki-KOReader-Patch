import re

sentence = "{geeks}{for freaks}"

def split_sentence(sentence):
    sentence_array = re.findall('{(.+?)}',sentence)
    part_one = sentence_array[0]
    part_two = sentence_array[1]

    return part_one, part_two

x, y = split_sentence(sentence)

print(str(x))
print(str(y))




